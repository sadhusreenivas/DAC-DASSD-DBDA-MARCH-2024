package com.example.jpa.dao;

import com.example.jpa.entity.Student;

public interface StudentDao {
    
	void save(Student stud);
}
