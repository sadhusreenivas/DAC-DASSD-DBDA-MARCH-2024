package com.example.jpa.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jpa.dao.StudentDao;
import com.example.jpa.entity.Student;

@RestController
public class DBRestController {
	@Autowired
	private StudentDao studentDao;

	// service - calls save method of DAO
	Student s1 = new Student("ABC", 8.9);
	
	@GetMapping("/add")
	public String save() {
		studentDao.save(s1); 
		
		return "Student Saved (inserted)";
	}
	
	@GetMapping("/hello")
	public String hello() {
		return "Hello";
	}
}
