package com.example.empd.services;

import java.util.List;
import java.util.Optional;

import com.example.empd.entities.Employee;

public interface EmployeeService {
	
	List<Employee> findAll();
	Optional<Employee> findById(int empId);
	Employee save(Employee emp); // save and update
	void deleteById(int empId);

}
